# NP AI Generator Pro

Mobile-first Image to Prompt and Video to Prompt studio.

## Features
- Image deep visual analysis with strict JSON schema.
- Exact image keys requested by NP AI Generator.
- Video duration detection with FFmpeg/FFprobe.
- Automatic 8-second segmentation, including a shorter final segment.
- 3 keyframes per segment.
- Independent segment analysis with continuity instructions.
- Character Lock option.
- Aspect ratio selector.
- Copy prompt, copy JSON, download TXT/JSON.
- Render-ready Dockerfile and render.yaml.

## Environment
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-5.6-luna
PORT=10000

## Local
npm install
npm start

## Render
Create a Web Service from this repo, choose Docker, and add OPENAI_API_KEY as an Environment Variable. Free Render web services are intended for testing/hobby use and spin down after 15 minutes idle. Uploaded files on the local filesystem are temporary, so this MVP processes files during the request and does not promise permanent storage.

## Important
The app generates prompts and analyzes media. It does not itself generate final AI video. A future paid video provider can be connected behind a separate /api/generate-video service without exposing provider keys to the browser.
